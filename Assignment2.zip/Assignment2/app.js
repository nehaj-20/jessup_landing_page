const http = require('http');
const fs = require('fs');



const server = http.createServer((request, response) => {
    if (request.url === '/dogs') {
        fs.readFile('views/dogs.html', 'utf8', (errors, contents) => {
            response.writeHead(200, { 'Content-Type': 'text/html' });
            response.write(contents);
            response.end();
        });
    } else if (request.url === '/images/dane.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/dane.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpg' });
            response.write(contents);
            response.end();
        })

    } else if (request.url === '/images/abrador.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/abrador.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpg' });
            response.write(contents);
            response.end();
        })

    } else if (request.url === '/images/French.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/French.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpg' });
            response.write(contents);
            response.end();
        })

    } else if (request.url === '/images/german.png') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/german.png', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/png' });
            response.write(contents);
            response.end();
        })

    } else if (request.url === '/images/poodle.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/poodle.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpg' });
            response.write(contents);
            response.end();
        })

    } else if (request.url === '/images/retriever.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/retriever.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpg' });
            response.write(contents);
            response.end();
        })



    } else if (request.url === "/cars") {
        fs.readFile('views/cars.html', 'utf8', (errors, contents) => {
            response.writeHead(200, { 'Content-type': 'text/html' });
            response.write(contents);
            response.end();
        });

    } else if (request.url === "/cars/new") {
        fs.readFile('views/cars/new.html', 'utf8', (errors, contents) => {
            response.writeHead(200, { 'Content-type': 'text/html' });
            response.write(contents);
            response.end();
        });

    } else if (request.url === '/images/car1.jpg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/car1.jpg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpg' });
            response.write(contents);
            response.end();
        })



    } else if (request.url === '/images/car2.jpg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/car2.jpg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpg' });
            response.write(contents);
            response.end();
        })
    } else if (request.url === '/images/audi.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/audi.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpeg' });
            response.write(contents);
            response.end();
        })
    } else if (request.url === '/images/benz.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/benz.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpeg' });
            response.write(contents);
            response.end();
        })

    } else if (request.url === '/images/bmw.jpeg') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/bmw.jpeg', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/jpeg' });
            response.write(contents);
            response.end();
        })

    } else if (request.url === '/images/tesla.png') {
        // notice we won't include the utf8 encoding
        fs.readFile('./images/tesla.png', function(errors, contents) {
            response.writeHead(200, { 'Content-type': 'image/png' });
            response.write(contents);
            response.end();
        })
    } else if (request.url === '/css/style.css') {
        fs.readFile('./css/style.css', 'utf8', (errors, contents) => {
            response.writeHead(200, { 'Content-type': 'text/css' });
            response.write(contents);
            response.end();
        });


    } else if (request.url === '/views/style.css') {
        fs.readFile('/views/css/style.css', 'utf8', (errors, contents) => {
            response.writeHead(200, { 'Content-type': 'text/css' });
            response.write(contents);
            response.end();
        });
    } else {


        response.end('File not found!!!');
    }
});



server.listen(7077);
console.log("listening on port 7077");